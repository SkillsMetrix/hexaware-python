

import  pandas as pd

chunksize=100000

for chunk in pd.read_csv('large_file.csv',chunksize=chunksize):
    print(chunk.shape)
    result=chunk[chunk['salary']>50000]
    print(result.head(5))
