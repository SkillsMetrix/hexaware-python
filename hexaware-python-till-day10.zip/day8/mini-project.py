import pandas as pd
from datetime import datetime

# Flights Data
flights_data = [
    {"flight_no": "AI101", "source": "Delhi", "destination": "Mumbai", "date": "2025-08-15", "available_seats": 120,
     "price": 5000},
    {"flight_no": "AI102", "source": "Mumbai", "destination": "Delhi", "date": "2025-08-15", "available_seats": 100,
     "price": 5200},
    {"flight_no": "AI201", "source": "Delhi", "destination": "Bengaluru", "date": "2025-08-16", "available_seats": 80,
     "price": 7000},
    {"flight_no": "AI202", "source": "Bengaluru", "destination": "Delhi", "date": "2025-08-16", "available_seats": 75,
     "price": 6800},
]
df_flights = pd.DataFrame(flights_data)
df_flights['date'] = pd.to_datetime(df_flights['date'])

print("\n=== Flights Data ===")
print(df_flights)

# Passengers Data
passengers_data = [
    {"passenger_id": 1, "name": "Alice", "contact": "alice@example.com"},
    {"passenger_id": 2, "name": "Bob", "contact": "bob@example.com"},
    {"passenger_id": 3, "name": "Charlie", "contact": "charlie@example.com"},
    {"passenger_id": 4, "name": "David", "contact": "david@example.com"},
]
df_passengers = pd.DataFrame(passengers_data)

print("\n=== Passengers Data ===")
print(df_passengers)

# Sales Data (Ticket Purchases)
sales_data = [
    {"sale_id": 1, "passenger_id": 1, "flight_no": "AI101", "tickets": 2},
    {"sale_id": 2, "passenger_id": 2, "flight_no": "AI101", "tickets": 1},
    {"sale_id": 3, "passenger_id": 3, "flight_no": "AI201", "tickets": 3},
    {"sale_id": 4, "passenger_id": 4, "flight_no": "AI102", "tickets": 1},
]
df_sales = pd.DataFrame(sales_data)

print("\n=== Sales Data ===")
print(df_sales)

# Purchase Data (Company Buys Parts/Services)
purchase_data = [
    {"purchase_id": 1, "item": "Jet Fuel", "vendor": "BP Aviation", "cost": 200000},
    {"purchase_id": 2, "item": "Aircraft Tyres", "vendor": "Goodyear", "cost": 50000},
    {"purchase_id": 3, "item": "Catering Service", "vendor": "SkyCater", "cost": 30000},
]
df_purchase = pd.DataFrame(purchase_data)

print("\n=== Purchase Data ===")
print(df_purchase)


print("merge and calculate sales revenue")

# merge sales with flight prices
df_sales_report=df_sales.merge(df_flights,on="flight_no",how="left")
# calculate revenue per sale
df_sales_report['revenue']=df_sales_report['tickets']* df_sales_report['price']
print("revenue")
print(df_sales_report[['sale_id','passenger_id','flight_no','tickets','price','revenue']])

# join with passenger details
df_full_sales=df_sales_report.merge(df_passengers,on="passenger_id",how="left")
print(df_full_sales[['name','flight_no','tickets','price','revenue']])

# Report-1 Total Revenue
tr=df_full_sales['revenue'].sum()
print(tr)
#print Top Passengers by Spending
top_ps=df_full_sales.groupby('name')['revenue'].sum().sort_values(ascending=False)
print(top_ps)

# Busy Routes by Ticket Sold
busy_routes=df_full_sales.groupby(['source','destination'])['tickets'].sum().sort_values(ascending=False)
print(busy_routes)
