import pandas as pd
import numpy as np

rows = 1_000_000  # 1 million rows
df = pd.DataFrame({
    'emp_id': np.arange(1, rows + 1),
    'name': [f'Employee{i}' for i in range(rows)],
    'salary': np.random.randint(30000, 120000, rows),
    'department': np.random.choice(['HR', 'IT', 'Finance', 'Sales'], rows)
})
df.to_csv('large_file.csv', index=False)
print("Dummy large file created.")