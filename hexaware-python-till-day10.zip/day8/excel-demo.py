import  pandas as pd


departments = pd.DataFrame({
    'DeptID': [1, 2, 3],
    'DeptName': ['HR', 'IT', 'Finance'],
    'Location': ['Mumbai', 'Pune', 'Delhi']
})
employees = pd.DataFrame({
    'EmpID': [101, 102, 103, 104, 105, 106],
    'Name': ['Alice', 'Bob', 'Charlie', 'David', 'Eva','sam'],
    'DeptID': [1, 2, 1, 3, 2, 4],
    'Salary': [70000, 80000, 65000, 72000, 69000, 45453]
})

employees.to_excel('employees.xlsx')
departments.to_excel('departments.xlsx')

emp_df=pd.read_excel('employees.xlsx',engine='openpyxl')
dept_df=pd.read_excel('departments.xlsx',engine='openpyxl')
# merge the data
combine_df=pd.merge(emp_df,dept_df,on='DeptID',how='left')
print(combine_df)
print("print merged data")
with pd.ExcelWriter('HR_Report.xlsx',engine="openpyxl") as writer:
    combine_df.to_excel(writer,sheet_name="EmployeeDetails",index=False)
    # department wise summary
    summary=combine_df.groupby('DeptID').agg(
        Total_Employees=("EmpID","count"),
        Average_Salary=("Salary","mean")
    ).reset_index()
    summary.to_excel(writer,sheet_name="SalaySummary",index=False)
print("report is ready")