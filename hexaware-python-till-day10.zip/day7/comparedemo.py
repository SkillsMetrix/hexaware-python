import numpy as np
import time
""" matrix= [[23,45],[56,65]]

arr= np.array([[23,45],[56,65]])

print(matrix[1][0])
print(arr[1][0])
 """
size=1000000
list1= list(range(size))
list2=list(range(size))

arr1= np.array(list1)
arr2= np.array(list2)
# regular addition
start= time.time()
list_sum=[x+y for x,y in zip(list1,list2)]
end= time.time()
print(f"List addition time : {end-start}")

# numpy addition
start= time.time()
arr_sum=arr1+arr2
end= time.time()
print(f"Numpy addition time : {end-start}")