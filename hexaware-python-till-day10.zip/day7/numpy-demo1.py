
import numpy as np

my_list=[10,23,54,66]

mArray= np.array(my_list)
print("Simple Array ",mArray)

 

