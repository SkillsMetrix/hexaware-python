
import numpy as np
data= np.array([12,34,65,77],dtype=np.int32)
print(data.dtype)
""" data2= np.array([11,35,66,90])
number=2
result = data + number
print(result)


result2= data + data2
print(result2)

result3= data2 > 50
print(result3) """