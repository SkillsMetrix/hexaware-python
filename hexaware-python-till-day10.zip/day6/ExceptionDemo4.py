def addAge(age):
    if(age < 18):
        raise ValueError("Age must be 18 to Vote")
    print(f"Age is {age}")


try:
    addAge(16)
except ValueError as e:
    print(e)

username='demo'
num=10
print(username+num)