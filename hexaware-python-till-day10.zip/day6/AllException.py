class InvalidAgeError(Exception):
    pass  
class NegativeSalaryError(Exception):
    pass  
class EmptyNameError(Exception):
    pass
class ItemNotFoundError(Exception):
    pass
class EmptyCartError(Exception):
    pass