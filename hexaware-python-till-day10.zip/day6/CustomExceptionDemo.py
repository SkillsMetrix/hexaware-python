
from AllException import *
class Employee:
    def __init__(self, name, salary, age):
        if not name.strip():
            raise EmptyNameError("Employee name is empty")
        if age <18:
            raise InvalidAgeError("Employee age is less than 18 (must be between 18 to 60)")
        if salary < 0:
            raise NegativeSalaryError("Employee salary is less than 0")

        self.name = name
        self.salary = salary
        self.age = age

    def __str__(self):
        return f"emp name:{self.name} , age: {self.age}, sal: {self.salary}"

try:
    empData = Employee("sam", 5000, 10)
    print(empData)
    

except EmptyNameError as e:
    print('EmptyNameError',e)
except NegativeSalaryError as e:
    print('NegativeSalaryError',e)
except InvalidAgeError as ex:
    print('InvalidAgeError',ex)