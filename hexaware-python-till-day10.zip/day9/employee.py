
class Employee:
    def __init__(self,emp_id,name,department,salary):
        self.emp_id=emp_id
        self.name=name
        self.department=department
        self.salary=salary
    
    def __str__(self):
        return f"ID {self.emp_id},Name: {self.name},Dept: {self.department}, Salary: {self.salary}"