import sqlite3
from employee import Employee

DB_NAME="employee.db"

def connect_db():
    conn=sqlite3.connect(DB_NAME)
    return conn

def create_table():
    conn=connect_db()
    cursor= conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS employees(
        emp_id INTEGER PRIMARY KEY,
        name TEXT NOT NULL,
        department TEXT NOT NULL,
        salary REAL NOT NULL
        )
        ''')
    conn.commit()
    conn.close
def insert_employee(emp: Employee):
    conn= connect_db()
    cursor= conn.cursor()
    cursor.execute('insert into employees(emp_id,name,department,salary) values(?,?,?,?)',
    (emp.emp_id,emp.name,emp.department,emp.salary))
    conn.commit()
    conn.close()
    
def load_employees():
    conn= connect_db()
    cursor= conn.cursor()
    cursor.execute('select * from employees')
    rows=cursor.fetchall()
    conn.close()
    return [Employee(*row) for row in rows]

def load_employee_byid(emp_id):
    conn= connect_db()
    cursor= conn.cursor()
    cursor.execute('select * from employees where emp_id=?',(emp_id,))
    row=cursor.fetchone()
    conn.close()
    return Employee(*row) if row else None

def delete_employee(emp_id):
    conn= connect_db()
    cursor= conn.cursor()
    cursor.execute('delete from employees where emp_id=?',(emp_id,))
    conn.commit()
    conn.close()


def update_employee(emp:Employee):
    conn= connect_db()
    cursor= conn.cursor()
    cursor.execute('update employees set name=?,department=?,salary=? where emp_id=?',
                   (emp.name, emp.department, emp.salary,emp.emp_id)
                   )
    conn.commit()
    conn.close()
