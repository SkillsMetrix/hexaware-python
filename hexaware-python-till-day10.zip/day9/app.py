from db import (create_table,insert_employee,load_employees,load_employee_byid,update_employee,delete_employee)
from employee import Employee

def display_menu():
    print("\n-----Employee CRUD Menu----")
    print("1----Add Employee----")
    print("2----Load Employee----")
    print("3----load Employee by ID----")
    print("4----update Employee----")
    print("5----delete Employee----")
    print("6----Exit----")

def main():
    create_table()

    while True:
        display_menu()
        choice= input("Enter Choice to Perform Operations:  ")
        if choice =='1':
            emp_id=int(input('Enter Employee ID: '))
            name= input('Enter Employee Name:  ')
            dept= input('Enter Department Name:  ')
            salary= float(input('Enter Employee Salary:  '))
            emp= Employee(emp_id,name,dept,salary)
            insert_employee(emp)
            print('Employee Added')
        elif choice =='2':
            employees= load_employees()
            if not employees:
                print('NO Employee Found')
            else:
                for emp in employees:
                    print(emp)
        elif choice =='3':
            emp_id=int(input('Enter Employee ID to Search: '))
            emp= load_employee_byid(emp_id)
            if emp:
                print(emp)
            else:
                print('Employee Not Found')
        elif choice =='4':
            emp_id=int(input('Enter Employee ID to Update: '))
            emp= load_employee_byid(emp_id)
            if not emp:
                print('Employee Not Found')
            else:
                name=input(f"Enter New Name ({emp.name}): )")or emp.name
                dept = input(f"Enter New Department ({emp.department}): )") or emp.dept
                salary_input = input(f"Enter New Salary ({emp.salary}): )")
                salary = float(salary_input) if salary_input else emp.salary
                update_employee(Employee(emp_id,name,dept,salary))
                print("Employee Updated")

        elif choice =='5':
            emp_id=int(input('Enter Employee ID to Delete: '))
            delete_employee(emp_id)
            print("employee deleted")

        elif choice=='6':
            print('Exiting the app')
            break
        else:
            print('wrong choice')


if __name__ == '__main__':
    main()