from abc import ABC,abstractmethod


class RBI(ABC):
    @abstractmethod
    def deposit(self):
        pass
    @abstractmethod
    def withdraw(self):
        pass
    @abstractmethod
    def checkBalance(self):
        pass


""" 
class CitiBank(RBI):
    # overide method
    def deposit(self):
        print('money deposited to CITI')

bank2=CitiBank()
bank2.deposit() """