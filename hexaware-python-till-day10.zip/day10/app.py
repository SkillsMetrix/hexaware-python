
from flask import Flask,request,jsonify
from flask_migrate import Migrate
from database import db
from models import CartItem

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///shopping_cart.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
# init databse

db.init_app(app)
migrate=Migrate(app,db)

# Home App
@app.route('/',methods=['GET'])
def myHome():
    return  jsonify({"message":"welcome to my shopping cart"}), 200

# create new item

@app.route('/additem',methods=['POST'])
def addtocart():
    data= request.get_json()
    if not data.get('name') or not data.get('quantity') or not data.get('price'):

        return  jsonify({"error":"missing data"}), 400
    new_item=CartItem(
        name=data.get('name'),
        quantity=data.get('quantity'),
        price=data.get('price')
    )
    db.session.add(new_item)
    db.session.commit()
    return jsonify({"message":"added item", "item": new_item.to_dict()}), 201

#read the data
@app.route("/loadcart",methods=['GET'])
def loadcart():
    items= CartItem.query.all()
    return jsonify([item.to_dict() for item in items]), 200

# load with ID
@app.route("/cart/<int:item_id>",methods=['GET'])
def loadcartwithid(item_id):
    item=CartItem.query.get(item_id)
    if not item:
        return jsonify({"error":"item not found"}), 404
    return jsonify(item.to_dict()), 200


# update with ID
@app.route("/cart/<int:item_id>",methods=['PUT'])
def updatecart(item_id):
    item=CartItem.query.get(item_id)
    if not item:
        return jsonify({"error":"item not found"}), 404

    data = request.get_json()
    item.name = data.get('name',item.name)
    item.quantity = data.get('quantity',item.quantity)
    item.price = data.get('price',item.price)
    db.session.commit()
    return jsonify({"message":"Item Updated","item": item.to_dict()}), 200


# load with ID
@app.route("/cart/<int:item_id>",methods=['DELETE'])
def deletecartwithid(item_id):
    item=CartItem.query.get(item_id)
    if not item:
        return jsonify({"error":"item not found"}), 404
    db.session.delete(item)
    db.session.commit()
    return jsonify(item.to_dict()), 200

if __name__=="__main__":
    with app.app_context():
        db.create_all() # create table if not exist
    app.run(debug=True)
