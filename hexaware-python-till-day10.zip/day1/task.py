
user_data=[]

data= int(input('How many numbers you wana add ? '))
print(data)

for i in range(data):
    num= int(input(f" Enter number {i+1} "))
    user_data.append(num)
print(f" The Array value is  {user_data}")

# calculate evena and odd
for num in user_data:
    if(num%2==0):
        print(f"{num} is even number")
    else:
        print(f"{num} is odd number")

# calculate the addtion of all the values in array

total=0
for data in user_data:
    
    total +=num
print(f"Total addition is {total}")