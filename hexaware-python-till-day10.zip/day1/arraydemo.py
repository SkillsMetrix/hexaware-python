
userNames=['admin','manager','qa']

# standard output
for uname in userNames:
    print(f'user names : {uname}')

# with index positions

for index,uname in enumerate(userNames):
    print(f" Index: {index}, -> {uname.upper()}")