
from itertools import zip_longest
usernames=['alice','sam','bob','shalini','charlie']
marks=[90,45,67,90]


result=list(zip(usernames,marks))

#print(result)

#looping
for name,marks in zip_longest(usernames,marks,fillvalue='N/A'):
    print(f"{name} scored: {marks}")