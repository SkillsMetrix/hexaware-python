

class Student():
    city='NY'
    def __init__(self,rollno,name,subject,marks):
        self.rollno=rollno
        self.name=name
        self.subject=subject
        self.marks=marks

    def displayData(self):
        print(f"Name is {self.name} and subject is {self.subject}")
    
    def __str__(self):
            return f"{self.name} {self.subject} {self.marks} {self.rollno}"

""" stu= Student(213,'sam','computers',34)
print(stu)
stu.displayData() """


class SeniorStudent(Student):
     def __init__(self,rollno,name,subject,marks,extraClasses):
        super().__init__(rollno,name,subject,marks)
        self.extraClasses=extraClasses

stu= SeniorStudent(213,'sam','computers',34,'Maths')
stu.displayData()
