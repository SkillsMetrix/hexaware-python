
user_data=[]

data= int(input('How many numbers you wana add ? '))
print(data)

for i in range(data):
    num= int(input(f" Enter number {i+1} "))
    user_data.append(num)
print(f" The Array value is  {user_data}")