# simple print statement
print('welcome to python')

# declare var
age=21
name='adam'
city='NY'

print(name,city,age)

# formatted output

print(f'Hola ....! {name} ,i belongs to {city} and valid age is {age}')