
""" name= input('Enter Name')

print(f'welcome {name}') """

""" name,age=input('Enter user data').split()

print(f"the username is {name}")
print(f"Age is {age}") """

a= int(input('Enter the value of a  '))
b= int(input('Enter the value of b  '))

c=a+b
print(f"The Addition is  {c}")