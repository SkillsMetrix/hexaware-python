
from logger import logger
from config import FINAL_REPORT_PATH

def generate_report(df_active):
    try:
        report= df_active.groupby(['Branch_Code','Transaction_Type']).agg(
            Transaction_Count=('Transaction_Amount', 'count'),
            Total_Amount_USD=('Transaction_Amount_USD', 'sum'),
        ).reset_index()

        report.to_csv(FINAL_REPORT_PATH,index=False)
        logger.info(f" Final Report Generated : {FINAL_REPORT_PATH}")
    except Exception as e:
        logger.error(f"Failed to generate report due to {e}")
        raise