
import sqlite3
import pandas as pd
from config import DB_PATH, DB_EXPORT_PATH
from logger import logger

def create_database():
    try:
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS transactions (
                Account_Number INTEGER,
                Customer_Name TEXT,
                Branch_Code TEXT,
                Transaction_Date TEXT,
                Transaction_Type TEXT,
                Transaction_Amount REAL,
                Balance REAL,
                Currency TEXT,
                Account_Status TEXT
            )
        """)

        transactions_data = [
            (1001, 'john DOE', 'B001', '2024-01-15', 'Deposit', 5000, 15000, 'usd', 'Active'),
            (1002, 'alice SMITH', 'B002', '2024-02-10', 'Withdrawal', 2000, 8000, 'inr', 'Active'),
            (1003, 'Bob Johnson', 'B001', '2024-02-22', 'Deposit', 3000, 12000, 'usd', 'Closed'),
            (1004, 'Clara Oswald', 'B003', '2024-03-05', 'Deposit', 7000, 20000, 'eur', 'Active'),
            (1005, 'Daniel White', 'B002', '2024-03-12', 'Withdrawal', 1500, 6500, 'usd', 'Active')
        ]
        cursor.executemany("""
            INSERT INTO transactions VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, transactions_data)

        conn.commit()
        conn.close()
        logger.info("Database created successfully.")
    except Exception as e:
        logger.error(f"Error creating database: {e}")
        raise

def export_db_to_csv():
   try:
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    df= pd.read_sql_query("SELECT * FROM transactions", conn)
    df.to_csv(DB_EXPORT_PATH, index=False)
    conn.close()
    logger.info(f"Database exported successfully to CSV {DB_EXPORT_PATH}")
    return df
   except Exception as e:
       logger.error(f"Error exporting database: {e}")
       raise


