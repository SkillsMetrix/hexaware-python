import array as arr
#list
userdata=['hello',12,34.56,'c']

print(userdata)

arra_data= arr.array('d',[12,13,14])
arra_data.append(34)
print(arra_data)