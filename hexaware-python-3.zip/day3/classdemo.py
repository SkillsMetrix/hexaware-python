# create class
class Employee:
    name='adam'

    def show(self):
        print('method called '+ self.name)
    def takeInput(self,city):
        print(city)

# create an object

emp= Employee()
print(emp.name)
emp.show()
emp.takeInput('NY')
