
# simplest way
basicData=[2,4,70,9,6]

# create an empty list

result=[]

for val in basicData:
    result.append(val*2)
print(result)

# Using list comp

res=[val * 2 for val in basicData]
print (res)

greater_than=[ num for num in basicData if num >40]
print(greater_than)
