
class Employee:
    name='admin'
    # constructor
    def __init__(self,age,city):
        self.age=age
        self.city=city
 
    # predefined function ,which gets called once you print the object
    def __str__(self):
        return f"{self.age}--{self.city}"

emp= Employee(21,'Mumbai')
emp2= Employee(22,'NY')
print(emp)
print(emp2)
