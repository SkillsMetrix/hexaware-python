employees=[
    {"name":"Alice","age":24,"city":"Mumbai"},
    {"name":"Bob","age":30,"city":"Delhi"},
    {"name":"David","age":28,"city":"Pune"},
    {"name":"Charlie","age":22,"city":"Delhi"},
    {"name":"Eva","age":35,"city":"Mumbai"}
]
# print only the names

name=[emp["name"] for emp in employees]
print(name)
name=[emp["name"] for emp in employees if emp["age"] > 25]
print(name)
mumbai_data=[emp["name"] for emp in employees if emp["city"].lower() =="mumbai"]
print(mumbai_data)
user_summary=[f"{emp['name']} from {emp['city']} is {emp['age']} years old" for emp in employees]
for data in user_summary:
    print(data)
