
def showName():
    print('welcome to function')

showName()

def showName2(name):
    print('welcome to function '+ name)

showName2('Adam')

def showName2(name='default'):
    print('welcome to function '+ name)


showName2('Adam')