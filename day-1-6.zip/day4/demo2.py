
class Employee:
 

    def __init__(self,name,email,salary):
        self.uname=name
        self.usalary=salary
        self.uemail=email
    
    def __repr__(self):
        return f"Employee( '{self.uname}' , '{self.uemail}' , '{self.usalary})'"
    
    @property
    def email(self):
        return f"{self.uname.lower()}@hexaware.com"
    @property
    def name(self):
        return f"{self.uname}"
    @property
    def salary(self):
        return f"{self.usalary}"
    @salary.setter
    def salary(self,value):
        if value < 0:
            raise ValueError("Salary must  be non-negative")
        self.usalary=value

emp=Employee('user1','user@mail.com',3000)

print(repr(emp))
print(emp.uemail)
emp.usalary=-1
print(emp.usalary)
    