from RBIBase import RBI

class JPMC(RBI):
    # overide method
    def deposit(self):
        print('money deposited to JPMC')
    def withdraw(self):
        print('money deposited to JPMC')
    def checkBalance(self):
        print('money deposited to JPMC')

bank=JPMC()
bank.deposit()