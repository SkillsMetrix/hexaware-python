usernames=['alice','sam','bob','shalini','charlie']
marks=[90,45,67,90]

sorteddata=sorted(marks)
sorteddata2=sorted(usernames)
print(f"{sorteddata}")
print(f"{sorteddata2}")