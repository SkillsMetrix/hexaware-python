basicNumber=10
response=0
try:
    response=basicNumber/10
except ZeroDivisionError:
    print('please pass the correct value')

print(response)