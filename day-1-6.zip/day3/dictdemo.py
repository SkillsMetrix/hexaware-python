
userdata={101:'usr1',102:'usr2'}

print(userdata.get(101))

# del ,pop ,clear
del userdata[101]
print(userdata)

users={101:'amit',102:'shreya',103: {'dep':'testing','dep':'finance'}}

print(users)