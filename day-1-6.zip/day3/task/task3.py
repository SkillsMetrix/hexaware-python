
#sol1

""" def sumOfArray(arr):
    total=0
    for num in arr:
        total +=num
    return total

numbers=[23,54,62,11]
result= sumOfArray(numbers)
print(f"Addition is  {result}")
 """
#sol2

""" def sumOfArray(*arr):
    total=0
    for num in arr:
        total +=num
    return total

 
result= sumOfArray(23,54,62,11)
print(f"Addition is  {result}") """

def userdata(**kwargs):
    print("Arguments ",kwargs)
    for key, value in kwargs.items():
        print(f"{key}: {value}")

userdata(name="sam",age=34,city="NY")